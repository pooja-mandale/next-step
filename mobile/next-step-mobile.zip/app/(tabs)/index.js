import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Linking,
  ActivityIndicator,
  FlatList,
  TextInput,
  StyleSheet,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useGetSchemesQuery } from '../../redux/api/schemeApi';
import { useSelector } from 'react-redux';
import { selectCurrentUser } from '../../redux/slices/authSlice';
import { useRouter } from 'expo-router';
import { useVerifySecretCodeMutation } from '../../redux/api/userApi';
import { useTheme } from '../../context/ThemeContext';

export default function HomeScreen() {
  const user = useSelector(selectCurrentUser);
  const router = useRouter();
  const { isDark, toggleTheme, colors: c } = useTheme();
  const { data: schemes, isLoading, refetch } = useGetSchemesQuery();
  const [searchText, setSearchText] = useState('');
  const [isChatUnlocked, setIsChatUnlocked] = useState(false);
  const [verifySecretCode] = useVerifySecretCodeMutation();

  const handleOpenLink = (url) => {
    if (url) Linking.openURL(url).catch((err) => console.error("Couldn't load page", err));
  };

  const handleSearchChange = async (text) => {
    setSearchText(text);
    if (text.length >= 4) {
      try {
        await verifySecretCode({ code: text }).unwrap();
        setIsChatUnlocked(true);
        setSearchText('');
      } catch {
        setIsChatUnlocked(false);
      }
    } else {
      setIsChatUnlocked(false);
    }
  };

  const filteredSchemes = schemes?.filter((s) =>
    s.name?.toLowerCase().includes(searchText.toLowerCase()) ||
    s.description?.toLowerCase().includes(searchText.toLowerCase())
  );

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: c.bg }]}>
        <ActivityIndicator size="large" color="#2563EB" />
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: c.bg }]}>
      <FlatList
        data={filteredSchemes}
        keyExtractor={(item) => item._id}
        contentContainerStyle={{ paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <>
            {/* ── Gradient Header ── */}
            <LinearGradient
              colors={isDark ? ['#1a1a2e', '#16213e'] : ['#1E3A8A', '#3B82F6']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.header}
            >
              {/* Top row: greeting + dark mode toggle + refresh */}
              <View style={styles.headerTop}>
                <View>
                  <Text style={styles.headerGreeting}>Hello, 👋</Text>
                  <Text style={styles.headerName}>{user?.name || 'User'}</Text>
                </View>

                {/* Dark mode toggle in header */}
                <View style={styles.headerRight}>
                  <View style={styles.toggleRow}>
                    <Ionicons
                      name={isDark ? 'moon' : 'sunny-outline'}
                      size={16}
                      color="rgba(255,255,255,0.85)"
                    />
                    <Switch
                      value={isDark}
                      onValueChange={toggleTheme}
                      trackColor={{ false: 'rgba(255,255,255,0.25)', true: '#3B82F6' }}
                      thumbColor="#fff"
                      style={{ transform: [{ scaleX: 0.85 }, { scaleY: 0.85 }] }}
                    />
                  </View>
                  <TouchableOpacity onPress={() => refetch()} style={styles.refreshBtn}>
                    <Ionicons name="refresh-outline" size={18} color="#fff" />
                  </TouchableOpacity>
                </View>
              </View>

              {/* Search Bar */}
              <View style={[styles.searchBar, {
                backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.18)',
              }]}>
                <Ionicons name="search-outline" size={18} color="rgba(255,255,255,0.7)" />
                <TextInput
                  placeholder="Search for schemes..."
                  placeholderTextColor="rgba(255,255,255,0.5)"
                  style={styles.searchInput}
                  value={searchText}
                  onChangeText={handleSearchChange}
                />
                {searchText.length > 0 && (
                  <TouchableOpacity onPress={() => setSearchText('')}>
                    <Ionicons name="close-circle" size={18} color="rgba(255,255,255,0.6)" />
                  </TouchableOpacity>
                )}
              </View>
            </LinearGradient>

            {/* ── Chat Unlock Banner ── */}
            {isChatUnlocked && (
              <TouchableOpacity
                onPress={() => router.push('/chats')}
                activeOpacity={0.85}
                style={[styles.chatBanner, { backgroundColor: isDark ? '#1d4ed8' : '#2563EB' }]}
              >
                <View style={styles.chatBannerIcon}>
                  <Ionicons name="chatbubble-ellipses" size={22} color="#fff" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.chatBannerTitle}>Chats Unlocked!</Text>
                  <Text style={styles.chatBannerSub}>Start a private conversation</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.8)" />
              </TouchableOpacity>
            )}

            {/* ── Section Heading ── */}
            <View style={styles.sectionHeader}>
              <View>
                <Text style={[styles.sectionTitle, { color: c.text }]}>Latest Schemes</Text>
                <View style={styles.sectionUnderline} />
              </View>
              <TouchableOpacity>
                <Text style={styles.viewAll}>View All</Text>
              </TouchableOpacity>
            </View>
          </>
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            activeOpacity={0.88}
            style={[styles.card, { backgroundColor: c.card, borderColor: c.cardBorder }]}
          >
            <View style={[styles.tag, {
              backgroundColor: isDark ? 'rgba(59,130,246,0.18)' : '#EFF6FF',
            }]}>
              <Text style={styles.tagText}>{item.category || 'General'}</Text>
            </View>

            <Text style={[styles.cardTitle, { color: c.text }]} numberOfLines={2}>
              {item.name}
            </Text>

            <Text style={[styles.cardDesc, { color: c.subText }]} numberOfLines={2}>
              {item.description}
            </Text>

            <View style={[styles.cardFooter, { borderTopColor: c.cardBorder }]}>
              <View style={styles.deadlineRow}>
                <Ionicons name="calendar-outline" size={14} color={c.subText} />
                <Text style={[styles.deadlineText, { color: c.subText }]}>
                  {item.deadline || 'No Deadline'}
                </Text>
              </View>
              <TouchableOpacity
                onPress={() => handleOpenLink(item.link)}
                style={styles.applyBtn}
                activeOpacity={0.85}
              >
                <Text style={styles.applyText}>Apply</Text>
                <Ionicons name="arrow-forward" size={14} color="#fff" style={{ marginLeft: 4 }} />
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={() => (
          <View style={styles.emptyContainer}>
            <View style={[styles.emptyIcon, { backgroundColor: c.card }]}>
              <Ionicons name="document-text-outline" size={36} color={c.subText} />
            </View>
            <Text style={[styles.emptyText, { color: c.subText }]}>No schemes found</Text>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  /* Header */
  header: { paddingTop: 20, paddingBottom: 28, paddingHorizontal: 20 },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerGreeting: { color: 'rgba(255,255,255,0.7)', fontSize: 13, fontWeight: '500' },
  headerName: { color: '#fff', fontSize: 22, fontWeight: '800', letterSpacing: 0.3, textTransform: 'capitalize' },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 20,
    paddingHorizontal: 8,
    paddingVertical: 4,
    gap: 4,
  },
  refreshBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center', alignItems: 'center',
  },

  /* Search */
  searchBar: {
    flexDirection: 'row', alignItems: 'center',
    borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, gap: 10,
  },
  searchInput: { flex: 1, fontSize: 14, color: '#fff' },

  /* Chat Banner */
  chatBanner: {
    flexDirection: 'row', alignItems: 'center',
    marginHorizontal: 20, marginTop: 16,
    borderRadius: 18, padding: 16, gap: 12,
    shadowColor: '#2563EB', shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25, shadowRadius: 8, elevation: 5,
  },
  chatBannerIcon: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center', alignItems: 'center',
  },
  chatBannerTitle: { color: '#fff', fontWeight: '700', fontSize: 14 },
  chatBannerSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 2 },

  /* Section */
  sectionHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, marginTop: 24, marginBottom: 16,
  },
  sectionTitle: { fontSize: 18, fontWeight: '800' },
  sectionUnderline: {
    width: 28, height: 3, backgroundColor: '#2563EB', borderRadius: 4, marginTop: 4,
  },
  viewAll: { color: '#3B82F6', fontWeight: '700', fontSize: 13 },

  /* Cards */
  card: {
    marginHorizontal: 20, marginBottom: 14,
    borderRadius: 22, padding: 20, borderWidth: 1,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06, shadowRadius: 8, elevation: 3,
  },
  tag: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, marginBottom: 10 },
  tagText: { color: '#3B82F6', fontSize: 10, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8 },
  cardTitle: { fontSize: 16, fontWeight: '700', marginBottom: 6, lineHeight: 22 },
  cardDesc: { fontSize: 13, lineHeight: 19, marginBottom: 14 },
  cardFooter: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingTop: 14, borderTopWidth: 1,
  },
  deadlineRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  deadlineText: { fontSize: 12, fontWeight: '500' },
  applyBtn: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#2563EB', paddingHorizontal: 18, paddingVertical: 9, borderRadius: 12,
    shadowColor: '#2563EB', shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3, shadowRadius: 6, elevation: 3,
  },
  applyText: { color: '#fff', fontWeight: '700', fontSize: 13 },

  /* Empty */
  emptyContainer: { alignItems: 'center', paddingTop: 60 },
  emptyIcon: { width: 72, height: 72, borderRadius: 36, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  emptyText: { fontSize: 14, fontWeight: '500' },
});

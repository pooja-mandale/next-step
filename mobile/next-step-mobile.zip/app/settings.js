import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  ScrollView, Alert, ActivityIndicator,
  KeyboardAvoidingView, Platform, StyleSheet, Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useSelector } from 'react-redux';
import { selectCurrentUser } from '../redux/slices/authSlice';
import { useChangePasswordMutation, useSetSecretCodeMutation } from '../redux/api/userApi';
import { useTheme } from '../context/ThemeContext';

export default function SettingsScreen() {
  const router = useRouter();
  const user = useSelector(selectCurrentUser);
  const { isDark, colors: c } = useTheme();

  const [showPass, setShowPass] = useState({ current: false, new: false, confirm: false });
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passOpen, setPassOpen] = useState(false);

  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [pinOpen, setPinOpen] = useState(false);

  // ── Toast ──────────────────────────────────────────────────────────────────
  const [toastMsg, setToastMsg] = useState('');
  const toastAnim = useRef(new Animated.Value(0)).current;

  const showToast = (msg) => {
    setToastMsg(msg);
    Animated.sequence([
      Animated.timing(toastAnim, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.delay(2200),
      Animated.timing(toastAnim, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start();
  };

  const handlePinToggle = () => {
    if (user?.hasSecretCode) {
      showToast('Secret code already set. You cannot update it.');
      return;
    }
    setPinOpen(!pinOpen);
  };

  const [changePassword, { isLoading: changingPass }] = useChangePasswordMutation();
  const [setSecretCode, { isLoading: settingCode }] = useSetSecretCodeMutation();

  const handleChangePassword = async () => {
    if (!currentPass || !newPass || !confirmPass) {
      Alert.alert('Error', 'Please fill in all password fields.'); return;
    }
    if (newPass.length < 6) {
      Alert.alert('Error', 'New password must be at least 6 characters.'); return;
    }
    if (newPass !== confirmPass) {
      Alert.alert('Error', 'New password and confirm password do not match.'); return;
    }
    try {
      await changePassword({ currentPassword: currentPass, newPassword: newPass }).unwrap();
      Alert.alert('Success ✅', 'Password changed successfully!');
      setCurrentPass(''); setNewPass(''); setConfirmPass('');
      setPassOpen(false);
    } catch (err) {
      Alert.alert('Error', err?.data?.message || 'Failed to change password.');
    }
  };

  const handleSetCode = async () => {
    if (user?.hasSecretCode) {
      Alert.alert('Notice', 'Secret code is already set. You do not need to set it again.');
      return;
    }
    if (!pin || !confirmPin) { Alert.alert('Error', 'Please enter and confirm your secret code.'); return; }
    if (pin.length < 4) { Alert.alert('Error', 'Secret code must be at least 4 digits.'); return; }
    if (pin !== confirmPin) { Alert.alert('Error', 'Secret codes do not match.'); return; }
    Alert.alert(
      'Are you sure?',
      'This secret code CANNOT be reset or recovered if you forget it. Do you want to proceed?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Yes, Save it',
          onPress: async () => {
            try {
              await setSecretCode({ code: pin }).unwrap();
              Alert.alert('Success ✅', 'Secret code set successfully!');
              setPin(''); setConfirmPin('');
              setPinOpen(false);
            } catch (err) {
              Alert.alert('Error', err?.data?.message || 'Failed to set secret code.');
            }
          }
        }
      ]
    );
  };

  /* ── Reusable sub-components ── */
  const SectionCard = ({ icon, iconBg, title, subtitle, children, isOpen, onToggle }) => (
    <View style={[styles.sectionCard, { backgroundColor: c.card, borderColor: c.cardBorder }]}>
      <TouchableOpacity onPress={onToggle} style={styles.sectionHeader} activeOpacity={0.7}>
        <View style={[styles.sectionIcon, { backgroundColor: iconBg }]}>
          <Ionicons name={icon} size={21} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.sectionTitle, { color: c.text }]}>{title}</Text>
          <Text style={[styles.sectionSub, { color: c.subText }]}>{subtitle}</Text>
        </View>
        <Ionicons name={isOpen ? 'chevron-up' : 'chevron-down'} size={18} color={c.subText} />
      </TouchableOpacity>
      {isOpen && (
        <View style={[styles.sectionBody, { borderTopColor: c.cardBorder }]}>{children}</View>
      )}
    </View>
  );

  const PassInput = ({ label, value, onChangeText, show, onToggleShow, placeholder }) => (
    <View style={styles.fieldGroup}>
      <Text style={[styles.fieldLabel, { color: c.subText }]}>{label}</Text>
      <View style={[styles.fieldBox, { backgroundColor: c.inputBg, borderColor: c.inputBorder }]}>
        <Ionicons name="lock-closed-outline" size={17} color={c.icon} />
        <TextInput
          style={[styles.fieldInput, { color: c.text }]}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder || '••••••••'}
          placeholderTextColor={c.placeholder}
          secureTextEntry={!show}
          autoCapitalize="none"
        />
        <TouchableOpacity onPress={onToggleShow} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Ionicons name={show ? 'eye-off-outline' : 'eye-outline'} size={17} color={c.icon} />
        </TouchableOpacity>
      </View>
    </View>
  );

  const PinInput = ({ label, value, onChangeText }) => (
    <View style={styles.fieldGroup}>
      <Text style={[styles.fieldLabel, { color: c.subText }]}>{label}</Text>
      <View style={[styles.fieldBox, { backgroundColor: c.inputBg, borderColor: c.inputBorder }]}>
        <Ionicons name="keypad-outline" size={17} color={c.icon} />
        <TextInput
          style={[styles.fieldInput, { color: c.text, letterSpacing: 4 }]}
          value={value}
          onChangeText={onChangeText}
          placeholder="Enter PIN"
          placeholderTextColor={c.placeholder}
          secureTextEntry
          keyboardType="numeric"
          maxLength={6}
        />
      </View>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: c.bg }]}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: c.cardBorder }]}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={[styles.backBtn, { backgroundColor: isDark ? '#252540' : '#F1F5F9' }]}
        >
          <Ionicons name="arrow-back" size={20} color={c.text} />
        </TouchableOpacity>
        <View>
          <Text style={[styles.headerTitle, { color: c.text }]}>Settings</Text>
          <Text style={[styles.headerSub, { color: c.subText }]}>Security & account preferences</Text>
        </View>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

          {/* ── Change Password ── */}
          <SectionCard
            icon="lock-closed-outline"
            iconBg="#2563EB"
            title="Change Password"
            subtitle="Update your account password"
            isOpen={passOpen}
            onToggle={() => setPassOpen(!passOpen)}
          >
            <View style={{ paddingTop: 16 }}>
              <PassInput
                label="Current Password"
                value={currentPass}
                onChangeText={setCurrentPass}
                show={showPass.current}
                onToggleShow={() => setShowPass(s => ({ ...s, current: !s.current }))}
                placeholder="Your current password"
              />
              <PassInput
                label="New Password"
                value={newPass}
                onChangeText={setNewPass}
                show={showPass.new}
                onToggleShow={() => setShowPass(s => ({ ...s, new: !s.new }))}
                placeholder="Minimum 6 characters"
              />
              <PassInput
                label="Confirm New Password"
                value={confirmPass}
                onChangeText={setConfirmPass}
                show={showPass.confirm}
                onToggleShow={() => setShowPass(s => ({ ...s, confirm: !s.confirm }))}
                placeholder="Re-enter new password"
              />
              <TouchableOpacity
                onPress={handleChangePassword}
                disabled={changingPass}
                style={[styles.actionBtn, { backgroundColor: '#2563EB', opacity: changingPass ? 0.7 : 1 }]}
                activeOpacity={0.85}
              >
                {changingPass ? <ActivityIndicator color="#fff" /> : (
                  <>
                    <Ionicons name="checkmark-circle-outline" size={18} color="#fff" />
                    <Text style={styles.actionBtnText}>Update Password</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          </SectionCard>

          {/* ── Secret Code ── */}
          <SectionCard
            icon="keypad-outline"
            iconBg="#6366F1"
            title="Secret Code"
            subtitle="Create a 4–6 digit PIN for extra security"
            isOpen={pinOpen}
            onToggle={() => handlePinToggle()}
          >
            <View style={{ paddingTop: 16 }}>
              <View style={[styles.warningBox, {
                backgroundColor: isDark ? 'rgba(217,119,6,0.12)' : '#FFFBEB',
                borderColor: isDark ? 'rgba(217,119,6,0.3)' : '#FDE68A',
              }]}>
                <Ionicons name="warning-outline" size={17} color="#D97706" />
                <Text style={[styles.warningText, { color: isDark ? '#FCD34D' : '#92400E' }]}>
                  WARNING: This secret code cannot be reset or recovered if forgotten. Please keep it safe!
                </Text>
              </View>

              <PinInput label="Enter Secret Code (4–6 digits)" value={pin} onChangeText={setPin} />
              <PinInput label="Confirm Secret Code" value={confirmPin} onChangeText={setConfirmPin} />

              {pin.length > 0 && (
                <View style={styles.pinDots}>
                  {Array.from({ length: 6 }).map((_, i) => (
                    <View
                      key={i}
                      style={[
                        styles.dot,
                        { backgroundColor: i < pin.length ? '#6366F1' : (isDark ? '#252540' : '#E2E8F0') },
                      ]}
                    />
                  ))}
                </View>
              )}

              <TouchableOpacity
                onPress={handleSetCode}
                disabled={settingCode || user?.hasSecretCode}
                style={[styles.actionBtn, {
                  backgroundColor: '#6366F1',
                  opacity: (settingCode || user?.hasSecretCode) ? 0.7 : 1,
                }]}
                activeOpacity={0.85}
              >
                {settingCode ? <ActivityIndicator color="#fff" /> : (
                  <>
                    <Ionicons name="shield-checkmark-outline" size={18} color="#fff" />
                    <Text style={styles.actionBtnText}>
                      {user?.hasSecretCode ? 'Secret Code Already Set' : 'Save Secret Code'}
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          </SectionCard>

        {/* ── Security Tips ── */}
          <View style={[styles.tipCard, {
            backgroundColor: isDark ? 'rgba(217,119,6,0.1)' : '#FFFBEB',
            borderColor: isDark ? 'rgba(217,119,6,0.25)' : '#FDE68A',
          }]}>
            <View style={styles.tipHeader}>
              <Ionicons name="bulb-outline" size={17} color="#D97706" />
              <Text style={[styles.tipTitle, { color: isDark ? '#FCD34D' : '#92400E' }]}>Security Tips</Text>
            </View>
            <Text style={[styles.tipBody, { color: isDark ? '#FCD34D' : '#B45309' }]}>
              {'• Never share your password or secret code with anyone.\n'}
              {'• Use a combination of letters, numbers, and symbols for your password.\n'}
              {'• Change your password regularly for better security.'}
            </Text>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>

      {/* ── Toast Notification ── */}
      <Animated.View
        pointerEvents="none"
        style={[
          styles.toast,
          {
            backgroundColor: isDark ? '#1e2a45' : '#1E3A8A',
            opacity: toastAnim,
            transform: [{
              translateY: toastAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [20, 0],
              }),
            }],
          },
        ]}
      >
        <Ionicons name="lock-closed" size={16} color="#93C5FD" />
        <Text style={styles.toastText}>{toastMsg}</Text>
      </Animated.View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 20, paddingTop: 16, paddingBottom: 14,
    borderBottomWidth: 1, gap: 14,
  },
  backBtn: {
    width: 40, height: 40, borderRadius: 20,
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: 20, fontWeight: '800' },
  headerSub: { fontSize: 12, marginTop: 2 },
  scroll: { padding: 20, paddingBottom: 48 },

  sectionCard: {
    borderRadius: 22, marginBottom: 16,
    borderWidth: 1, overflow: 'hidden',
  },
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: 18, paddingVertical: 18, gap: 14,
  },
  sectionIcon: {
    width: 46, height: 46, borderRadius: 15,
    alignItems: 'center', justifyContent: 'center',
  },
  sectionTitle: { fontSize: 14, fontWeight: '700' },
  sectionSub: { fontSize: 12, marginTop: 2 },
  sectionBody: { paddingHorizontal: 18, paddingBottom: 18, borderTopWidth: 1 },

  fieldGroup: { marginBottom: 14 },
  fieldLabel: { fontSize: 11, fontWeight: '600', marginBottom: 7, marginLeft: 2 },
  fieldBox: {
    flexDirection: 'row', alignItems: 'center',
    borderWidth: 1.5, borderRadius: 14,
    paddingHorizontal: 14, paddingVertical: 12, gap: 10,
  },
  fieldInput: { flex: 1, fontSize: 14, height: 22 },

  actionBtn: {
    borderRadius: 14, paddingVertical: 14,
    flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', gap: 8, marginTop: 4,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25, shadowRadius: 8, elevation: 4,
  },
  actionBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },

  warningBox: {
    flexDirection: 'row', alignItems: 'flex-start',
    borderWidth: 1, borderRadius: 14,
    padding: 14, gap: 10, marginBottom: 16,
  },
  warningText: { flex: 1, fontSize: 12, fontWeight: '600', lineHeight: 18 },

  pinDots: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginBottom: 16 },
  dot: { width: 12, height: 12, borderRadius: 6 },

  tipCard: {
    borderRadius: 20, padding: 18, borderWidth: 1,
  },
  tipHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  tipTitle: { fontWeight: '700', fontSize: 13 },
  tipBody: { fontSize: 12, lineHeight: 20 },

  toast: {
    position: 'absolute',
    bottom: 36,
    left: 24,
    right: 24,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 8,
  },
  toastText: {
    color: '#BFDBFE',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
});

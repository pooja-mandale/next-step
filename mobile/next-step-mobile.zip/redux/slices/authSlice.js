import { createSlice } from '@reduxjs/toolkit';
import { setItem, deleteItem } from '../../utils/storage';

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    user: null,
    token: null,
  },
  reducers: {
    setCredentials: (state, action) => {
      const { user, token } = action.payload;
      state.user = user;
      state.token = token;
      if (token) {
        setItem('userToken', token);
      }
    },
    logout: (state) => {
      state.user = null;
      state.token = null;
      deleteItem('userToken');
    },
  },
});

export const { setCredentials, logout } = authSlice.actions;
export default authSlice.reducer;

export const selectCurrentUser = (state) => state.auth.user;
export const selectCurrentToken = (state) => state.auth.token;
